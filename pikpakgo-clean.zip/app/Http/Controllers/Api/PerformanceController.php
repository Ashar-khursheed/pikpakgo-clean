<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\UserCacheService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redis;

/**
 * @OA\Tag(
 *     name="Performance",
 *     description="Performance monitoring and cache statistics"
 * )
 */
class PerformanceController extends Controller
{
    protected $cacheService;

    public function __construct(UserCacheService $cacheService)
    {
        $this->cacheService = $cacheService;
    }

    /**
     * @OA\Get(
     *     path="/performance/cache-stats",
     *     tags={"Performance"},
     *     summary="Get Redis cache statistics",
     *     description="Returns comprehensive Redis cache performance metrics",
     *     security={{"bearerAuth":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="Cache statistics retrieved successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(
     *                 property="data",
     *                 type="object",
     *                 @OA\Property(property="connected_clients", type="integer", example=5),
     *                 @OA\Property(property="used_memory_human", type="string", example="2.5M"),
     *                 @OA\Property(property="total_keys", type="integer", example=1250),
     *                 @OA\Property(property="hit_rate", type="string", example="95.23%")
     *             )
     *         )
     *     ),
     *     @OA\Response(response=401, description="Unauthenticated")
     * )
     */
    public function cacheStats()
    {
        try {
            $stats = $this->cacheService->getCacheStats();

            return response()->json([
                'success' => true,
                'data' => $stats
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve cache statistics',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * @OA\Get(
     *     path="/performance/database-stats",
     *     tags={"Performance"},
     *     summary="Get database statistics",
     *     description="Returns database connection and performance metrics",
     *     security={{"bearerAuth":{}}},
     *     @OA\Response(
     *         response=200,
     *         description="Database statistics retrieved successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(
     *                 property="data",
     *                 type="object",
     *                 @OA\Property(property="connection", type="string", example="mysql"),
     *                 @OA\Property(property="total_users", type="integer", example=15234),
     *                 @OA\Property(property="active_users", type="integer", example=12450),
     *                 @OA\Property(property="database_size", type="string", example="125.3 MB")
     *             )
     *         )
     *     ),
     *     @OA\Response(response=401, description="Unauthenticated")
     * )
     */
    public function databaseStats()
    {
        try {
            $connection = DB::connection()->getDatabaseName();
            
            // Get table statistics
            $users = DB::table('users');
            $totalUsers = $users->count();
            $activeUsers = $users->where('status', 'active')->count();

            // Get database size
            $databaseSize = DB::select("
                SELECT 
                    ROUND(SUM(data_length + index_length) / 1024 / 1024, 2) as size_mb
                FROM information_schema.TABLES 
                WHERE table_schema = ?
            ", [$connection]);

            $stats = [
                'connection' => DB::connection()->getDriverName(),
                'database' => $connection,
                'total_users' => $totalUsers,
                'active_users' => $activeUsers,
                'database_size' => ($databaseSize[0]->size_mb ?? 0) . ' MB',
                'tables' => [
                    'users' => DB::table('users')->count(),
                    'host_profiles' => DB::table('host_profiles')->count(),
                    'agency_profiles' => DB::table('agency_profiles')->count(),
                ]
            ];

            return response()->json([
                'success' => true,
                'data' => $stats
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to retrieve database statistics',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * @OA\Get(
     *     path="/performance/health",
     *     tags={"Performance"},
     *     summary="Health check",
     *     description="Check application health including database and Redis connectivity",
     *     @OA\Response(
     *         response=200,
     *         description="Application is healthy",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Application is healthy"),
     *             @OA\Property(
     *                 property="data",
     *                 type="object",
     *                 @OA\Property(property="database", type="string", example="connected"),
     *                 @OA\Property(property="redis", type="string", example="connected"),
     *                 @OA\Property(property="timestamp", type="string", example="2024-12-22T10:30:00Z")
     *             )
     *         )
     *     ),
     *     @OA\Response(response=503, description="Service unavailable")
     * )
     */
    public function health()
    {
        $health = [
            'database' => 'disconnected',
            'redis' => 'disconnected',
            'timestamp' => now()->toIso8601String()
        ];

        $isHealthy = true;

        // Check database connection
        try {
            DB::connection()->getPdo();
            $health['database'] = 'connected';
        } catch (\Exception $e) {
            $isHealthy = false;
            $health['database_error'] = $e->getMessage();
        }

        // Check Redis connection
        try {
            Redis::ping();
            $health['redis'] = 'connected';
        } catch (\Exception $e) {
            $isHealthy = false;
            $health['redis_error'] = $e->getMessage();
        }

        $statusCode = $isHealthy ? 200 : 503;

        return response()->json([
            'success' => $isHealthy,
            'message' => $isHealthy ? 'Application is healthy' : 'Some services are unavailable',
            'data' => $health
        ], $statusCode);
    }

    /**
     * @OA\Post(
     *     path="/performance/clear-cache",
     *     tags={"Performance"},
     *     summary="Clear application cache",
     *     description="Clear all application caches (admin only)",
     *     security={{"bearerAuth":{}}},
     *     @OA\RequestBody(
     *         required=false,
     *         @OA\JsonContent(
     *             @OA\Property(property="type", type="string", enum={"all", "users", "config"}, example="all")
     *         )
     *     ),
     *     @OA\Response(
     *         response=200,
     *         description="Cache cleared successfully",
     *         @OA\JsonContent(
     *             @OA\Property(property="success", type="boolean", example=true),
     *             @OA\Property(property="message", type="string", example="Cache cleared successfully")
     *         )
     *     ),
     *     @OA\Response(response=401, description="Unauthenticated"),
     *     @OA\Response(response=403, description="Unauthorized - Admin only")
     * )
     */
    public function clearCache()
    {
        // Only allow admins to clear cache
        $user = auth()->user();
        
        if ($user->user_type !== 'admin') {
            return response()->json([
                'success' => false,
                'message' => 'Unauthorized. Admin access required.'
            ], 403);
        }

        try {
            $type = request()->input('type', 'all');

            switch ($type) {
                case 'users':
                    // Clear only user-related caches
                    $pattern = config('cache.prefix') . 'user:*';
                    $keys = Redis::keys($pattern);
                    if (!empty($keys)) {
                        Redis::del($keys);
                    }
                    break;

                case 'config':
                    \Artisan::call('config:clear');
                    break;

                case 'all':
                default:
                    \Artisan::call('cache:clear');
                    break;
            }

            return response()->json([
                'success' => true,
                'message' => 'Cache cleared successfully',
                'type' => $type
            ], 200);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'message' => 'Failed to clear cache',
                'error' => $e->getMessage()
            ], 500);
        }
    }
}
